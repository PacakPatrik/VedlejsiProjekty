﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Snake
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        enum directions {top,bottom,left,right};
        directions direction;
        List<Rectangle> body = new List<Rectangle>();
        Rectangle food = new Rectangle();
        bool Is_food_eaten=false;
        //bool Has_head_moved;
        Point last_position = new Point();
        double speed = 45;
        int score_counter=0;
        


        System.Windows.Threading.DispatcherTimer dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
        
        public MainWindow()
        {
            InitializeComponent();

            canvas.Focus();
            
            dispatcherTimer.Tick += new EventHandler(dispatcherTimer_Tick);
            dispatcherTimer.Interval = TimeSpan.FromMilliseconds(speed);
            dispatcherTimer.Start();

            //make_playground();
            create_head();
            create_food();
            respawn_food();

          

        }
        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            
            move_head();
            hit_your_tail_or_wall();
            hit_the_food();
            move_bodyparts();
            
        }

        void create_head()
        {
            Rectangle head = new Rectangle();
            head.Fill = Brushes.DarkGreen;
            head.Width = 10;
            head.Height = 10;
            canvas.Children.Add(head);
            body.Add(head);
            Canvas.SetLeft(head, 200);
            Canvas.SetTop(head, 200);
        }

        void create_food()
        {
            food.Width = 10;
            food.Fill = Brushes.Orange;
            food.Width = 10;
            food.Height = 10;
            canvas.Children.Add(food);
           
        }

        void respawn_food()
        {
            Random rnd = new Random();
            Canvas.SetLeft(food,rnd.Next(0, 44) * 10);
            Canvas.SetTop(food, rnd.Next(0, 42) * 10);
            
        }

        void hit_the_food()
        {
            if (Canvas.GetLeft(body[0]) == Canvas.GetLeft(food)
                && Canvas.GetTop(body[0]) == Canvas.GetTop(food))
            {
                Is_food_eaten = true;
               
                add_body_part();
                respawn_food();
                speed_up();
                score_up();
                //MessageBox.Show(body.Count.ToString());
            }
        }

        void add_body_part()
        {
            Rectangle bodypart = new Rectangle();
            bodypart.Width = 10;
            bodypart.Height = 10;
            bodypart.Fill = Brushes.LawnGreen;
            body.Add(bodypart);
            canvas.Children.Add(body[body.Count-1]);
            
            if (direction == directions.bottom)
            {
                Canvas.SetLeft(bodypart, Canvas.GetLeft(body[0]));
                Canvas.SetTop(bodypart, Canvas.GetTop(body[0])-10);

            }
            if (direction == directions.top)
            {
                Canvas.SetLeft(bodypart, Canvas.GetLeft(body[0]));
                Canvas.SetTop(bodypart, Canvas.GetTop(body[0]) + 10);
            }
            if (direction == directions.left)
            {
                Canvas.SetLeft(bodypart, Canvas.GetLeft(body[0])+10);
                Canvas.SetTop(bodypart, Canvas.GetTop(body[0]));
            }
            if (direction == directions.right)
            {
                Canvas.SetLeft(bodypart, Canvas.GetLeft(body[0])-10);
                Canvas.SetTop(bodypart, Canvas.GetTop(body[0]));
            }
        }

        void move_head()
        {
            last_position.X = Canvas.GetLeft(body[0]);
            last_position.Y = Canvas.GetTop(body[0]);
            if (direction == directions.bottom)
            {
                Canvas.SetTop(body[0], Canvas.GetTop(body[0]) + 10);
            }
            if (direction == directions.top)
            {
                Canvas.SetTop(body[0], Canvas.GetTop(body[0]) - 10);
            }
            if (direction == directions.left)
            {
                Canvas.SetLeft(body[0], Canvas.GetLeft(body[0]) - 10);
            }
            if (direction == directions.right)
            {
                Canvas.SetLeft(body[0], Canvas.GetLeft(body[0]) + 10);
            }
           
        }

        void hit_your_tail_or_wall()
        {
            for (int i = 1; i < body.Count; i++)
            {
                if (Canvas.GetLeft(body[0]) == Canvas.GetLeft(body[i])
                    && Canvas.GetTop(body[0]) == Canvas.GetTop(body[i]))
                {
                    restart();
                }
            }
            if ((Canvas.GetLeft(body[0]) < 0 || Canvas.GetLeft(body[0]) > 450) || ( Canvas.GetTop(body[0]) <0 || Canvas.GetTop(body[0]) > 430)){
                restart();
            }
        }

        void restart()
        {
            canvas.Children.Clear();
            //make_playground();
            body.Clear();
            create_head();
            create_food();
            respawn_food();
            score_counter = 0;
            score_label.Content = 0.ToString();
            speed = 45;
            dispatcherTimer.Interval = TimeSpan.FromMilliseconds(speed);
        }


        //void make_playground()
        //{
        //    for (int i = 0; i < 451; i += 10)
        //    {
        //        Line line = new Line();
        //        line.X1 = i;
        //        line.Y1 = 0;
        //        line.X2 = i;
        //        line.Y2 = canvas.Height;
        //        line.Stroke = Brushes.Black;
        //        line.StrokeThickness = 0.5;
        //        canvas.Children.Add(line);
        //    }
        //    for (int i = 0; i < 431; i += 10)
        //    {
        //        Line line = new Line();
        //        line.X1 = 0;
        //        line.Y1 = i;
        //        line.X2 = canvas.Width;
        //        line.Y2 = i;
        //        line.Stroke = Brushes.Black;
        //        line.StrokeThickness = 0.5;
        //        canvas.Children.Add(line);
        //    }
        //}

        void move_bodyparts()
        {
            if (body.Count > 1)
            {
              
                for (int i = 1; i < body.Count; i++)
                {
                    double x, y;
                    x = last_position.X;
                    y = last_position.Y;
                    last_position.X = Canvas.GetLeft(body[i]);
                    last_position.Y = Canvas.GetTop(body[i]);
                    Canvas.SetLeft(body[i], x);
                    Canvas.SetTop(body[i], y);
                }
            }

        }


        void speed_up()
        {
            if (speed > 20)
            {
                speed -= 0.5;
                dispatcherTimer.Interval = TimeSpan.FromMilliseconds(speed);
            }
        }

        void score_up()
        {
            score_counter++;
            score_label.Content = score_counter.ToString();
        }

        private void window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
                if (e.Key == Key.Down)
                {
                    //MessageBox.Show("hej");
                    direction = directions.bottom;
                //Canvas.SetTop(body[0], Canvas.GetTop(body[0]) + 10);
                //dispatcherTimer.Stop();
                //dispatcherTimer.Start();
                }
                if (e.Key == Key.Up)
                {
                    direction = directions.top;
                //Canvas.SetTop(body[0], Canvas.GetTop(body[0]) - 10);
                //dispatcherTimer.Stop();
                //dispatcherTimer.Start();
            }
                if (e.Key == Key.Left)
                {
                    direction = directions.left;
                //Canvas.SetLeft(body[0], Canvas.GetLeft(body[0]) - 10);
                //dispatcherTimer.Stop();
                //dispatcherTimer.Start();
            }
                if (e.Key == Key.Right)
                {
                    direction = directions.right;
                //Canvas.SetLeft(body[0], Canvas.GetLeft(body[0]) + 10);
                //dispatcherTimer.Stop();
                //dispatcherTimer.Start();
            }
                     
        }

    }
}
