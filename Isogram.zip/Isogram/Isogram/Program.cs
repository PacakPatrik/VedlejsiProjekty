﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Isogram
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "";
            Console.WriteLine("enter string");
            str = Console.ReadLine();
            Console.WriteLine(IsIsogram(str));
            Console.ReadLine();
        }
        public static bool IsIsogram(string str)
        {
            int lettercount=0;
           
            for(int i = 0; i < str.Length; i++)
            {
              
                for (int j = 0; j < str.Length; j++)
                {
                    if (str.Substring(i, 1) == str.Substring(j, 1))
                    {
                        lettercount++;
                        if ((Char.IsLower(Convert.ToChar(str.Substring(i, 1))) && Char.IsUpper(Convert.ToChar(str.Substring(j, 1))))
                             || (Char.IsUpper(Convert.ToChar(str.Substring(i, 1))) && Char.IsLower(Convert.ToChar(str.Substring(j, 1)))))
                        {
                            lettercount++;
                        }

                    }
                }
                if (lettercount > 1)
                {   
                    break;
                }
                else
                {
                    lettercount = 0;
                }
            }
            if (lettercount > 1)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
