﻿using System;
using System.Threading;
using System.Timers;
using System.Collections.Generic;
using System.Drawing;

namespace ConveysGameOfLife
{
    class Program
    {
        private static System.Threading.Timer timer;
        static bool[,] plocha = new bool[50, 70];
        static bool[,] aktualizovanaPlocha = new bool[50, 70];
        static void Main(string[] args)
        {




            vykreslit(plocha);

            Console.WriteLine();
            Console.SetCursorPosition(0, 0);

            bool Continue = true;
            while (Continue)
            {

                switch (Console.ReadKey().Key)
                {

                    case ConsoleKey.X:
                        Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                        Console.Write("*");
                        plocha[Console.CursorLeft - 1, Console.CursorTop] = true;
                        break;
                    case ConsoleKey.UpArrow:
                        Console.SetCursorPosition(Console.CursorLeft, Console.CursorTop - 1);
                        break;
                    case ConsoleKey.DownArrow:
                        Console.SetCursorPosition(Console.CursorLeft, Console.CursorTop + 1);
                        break;
                    case ConsoleKey.LeftArrow:
                        Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                        break;
                    case ConsoleKey.RightArrow:
                        Console.SetCursorPosition(Console.CursorLeft + 1, Console.CursorTop);
                        break;
                    case ConsoleKey.E:
                        Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                        Console.Write("#");
                        Continue = false;
                        break;
                }


            }
            //Console.WriteLine("Zadej x startovaci bod pro blok");
            //startX = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Zadej y startovaci bod pro blok");
            //startY = Convert.ToInt32(Console.ReadLine());


            //Console.SetCursorPosition(startX, startY);
            //Console.Write("*");
            //plocha[startX, startY] = true;
            //aktualizovanaPlocha[startX, startY] = true;
            //Console.SetCursorPosition(startX + 1, startY);
            //Console.Write("*");
            //plocha[startX + 1, startY] = true;
            //aktualizovanaPlocha[startX + 1, startY] = true;
            //Console.SetCursorPosition(startX, startY + 1);
            //Console.Write("*");
            //plocha[startX, startY + 1] = true;
            //aktualizovanaPlocha[startX, startY + 1] = true;
            //Console.SetCursorPosition(startX + 1, startY + 1);
            //Console.Write("*");
            //plocha[startX + 1, startY + 1] = true;
            //aktualizovanaPlocha[startX + 1, startY + 1] = true;


            timer = new System.Threading.Timer(TimerCallback, null, 0, 100);

            Console.ReadLine();
        }




        public static void vykreslit(bool[,] plocha)
        {
            for (int i = 0; i < plocha.GetLength(0); i++)
            {
                for (int j = 0; j < plocha.GetLength(1); j++)
                {
                    Console.Write("#");
                    plocha[i, j] = false;
                    aktualizovanaPlocha[i, j] = false;
                }
                Console.WriteLine();
            }
        }


        public static void PrepsatHodnoty(ref bool[,] aktualizovanaPlocha)
        {
            for (int i = 0; i < plocha.GetLength(0); i++)
            {
                for (int j = 0; j < plocha.GetLength(1); j++)
                {
                    if (plocha[i, j] && !aktualizovanaPlocha[i, j])
                    {
                        Console.SetCursorPosition(i, j);
                        Console.Write("#");
                    }
                    else if (aktualizovanaPlocha[i, j])
                    {
                        Console.SetCursorPosition(i, j);
                        Console.Write("*");
                    }





                }
            }
        }

        private static void TimerCallback(Object o)
        {
            for (int i = 0; i < plocha.GetLength(0); i++)
            {
                for (int j = 0; j < plocha.GetLength(1); j++)
                {

                    CheckCells(ref i, ref j, ref plocha, ref aktualizovanaPlocha);

                }
            }

            PrepsatHodnoty(ref aktualizovanaPlocha);
            for (int i = 0; i < plocha.GetLength(0); i++)
            {
                for (int j = 0; j < plocha.GetLength(1); j++)
                {

                    plocha[i, j] = aktualizovanaPlocha[i, j];

                }
            }



            //zde se provede kdo pro timer
        }
        public static void CheckCells(ref int i, ref int j, ref bool[,] plocha, ref bool[,] aktualizovanaPlocha)
        {
            int numberOfAliveCells = 0;
            //doprava
            #region kontrolaZivotnosti
            if ((j + 1) < plocha.GetLength(1) && plocha[i, j + 1] == true)
            {
                numberOfAliveCells++;
            }
            //doleva
            if ((j - 1) > 0 && plocha[i, j - 1] == true)
            {
                numberOfAliveCells++;
            }

            //dolu
            if ((i + 1) < plocha.GetLength(0) && plocha[i + 1, j] == true)
            {
                numberOfAliveCells++;
            }
            //nahoru
            if ((i - 1) > 0 && plocha[i - 1, j] == true)
            {
                numberOfAliveCells++;
            }

            //vlev onahore
            if ((j - 1) > 0 && (i - 1) > 0)
            {
                if (plocha[i - 1, j - 1] == true)
                {
                    numberOfAliveCells++;
                }
            }
            //vpravo nahore
            if ((j + 1) < plocha.GetLength(1) && (i - 1) > 0)
            {
                if (plocha[i - 1, j + 1] == true)
                {
                    numberOfAliveCells++;
                }
            }
            //vlevo dole
            if ((j - 1) > 0 && (i + 1) < plocha.GetLength(0))
            {
                if (plocha[i + 1, j - 1] == true)
                {
                    numberOfAliveCells++;
                }
            }
            //vpravo dole
            if ((j + 1) < plocha.GetLength(1) && (i + 1) < plocha.GetLength(0))
            {
                if (plocha[i + 1, j + 1] == true)
                {
                    numberOfAliveCells++;
                }
            }
            #endregion

            if (plocha[i, j] && numberOfAliveCells == 2)
            {
                aktualizovanaPlocha[i, j] = true;
            }

            if (numberOfAliveCells < 2 || numberOfAliveCells > 3)
            {
                aktualizovanaPlocha[i, j] = false;
                //Console.SetCursorPosition(i, j);
                //Console.Write("#");

            }
            if (numberOfAliveCells == 3)
            {
                aktualizovanaPlocha[i, j] = true;
                //Console.SetCursorPosition(i, j);
                //Console.Write("*");
            }
        }
    }
}