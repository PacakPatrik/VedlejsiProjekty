﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace WordTripNaTripu
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> slovnik = new List<string>();
            string[] radky = File.ReadAllLines(Directory.GetCurrentDirectory()+@"\words.txt");
            foreach(string radek in radky)
            {
                if(radek.Length>=3 && radek.Length <= 5)
                {
                    slovnik.Add(radek);
                }
            }

            Console.WriteLine("Zadej znaky");

            string znaky = Console.ReadLine().ToLower();
            Console.WriteLine();
            List<string> pismena = new List<string>();
            string znaky2 = "";
            List<string> naseSlova = new List<string>();
            List<string> ctyrkoveSlova = new List<string>();
            for (int j = 0; j < 5; j++)
            {
                if (j == 0)
                {
                    pismena = FindPermutations(znaky);
                }
                else
                {
                    pismena = FindPermutations(znaky2);
                }
                for (int i = 0; i < pismena.Count; i++)
                {

                    naseSlova.Add(pismena[i]);
                    if (pismena[i].Length > 3)
                    {
                        ctyrkoveSlova.Add(pismena[i]);
                    }
                }
                znaky2 = znaky.Remove((znaky.Length - 1) - j, 1);

            }
            


                for (int i = 0; i < ctyrkoveSlova.Count; i++)
                {

                    for (int k = 0; k < ctyrkoveSlova[i].Length; k++)
                    {
                        string slovo = ctyrkoveSlova[i].Remove((ctyrkoveSlova[i].Length - 1) - k, 1);
                        pismena = FindPermutations(slovo);
                        for (int j = 0; j < pismena.Count; j++)
                        {

                            naseSlova.Add(pismena[j]);

                        }

                    }
                }
            
            Console.WriteLine();
            for (int i = 0; i < naseSlova.Count; i++)
            {
                string slovo = naseSlova[i];
                for (int j = 0; j < naseSlova.Count; j++)
                {
                    if (i == j)
                    {
                        continue;
                    }
                    else if (slovo == naseSlova[j])
                    {
                        naseSlova.RemoveAt(j);
                    }
                }
            }
            for (int i = 0; i < naseSlova.Count; i++)
            {
                Console.WriteLine(naseSlova[i]);
            }

            for (int i = 0; i < naseSlova.Count; i++)
            {
                for (int j = 0; j < slovnik.Count; j++)
                {
                    if (naseSlova[i] == slovnik[j])
                    {
                        Console.WriteLine(naseSlova[i]);
                    }
                }
            }
            
            









            }
            public static List<string> FindPermutations(string set)
            {
            var output = new List<string>();
            if (set.Length == 1)
            {
                output.Add(set);
            }
            else
            {
                foreach (var c in set)
                {
                    // Remove one occurrence of the char (not all)
                    var tail = set.Remove(set.IndexOf(c), 1);
                    foreach (var tailPerms in FindPermutations(tail))
                    {
                        output.Add(c + tailPerms);
                    }
                }
            }
            return output;
        }
    }
   
}

