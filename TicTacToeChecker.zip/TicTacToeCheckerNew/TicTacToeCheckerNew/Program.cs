﻿using System;
using System.Windows;
using System.Drawing;
using System.Collections.Generic;

namespace TicTacToeCheckerNew
{
    class Program
    {
        
        public static int IsSolved(int[,] board)
        {
            List<Point> solutionsOnBoardX = new List<Point>();
            List<Point> solutionsOnBoardO = new List<Point>();
            bool Is_finished = true;
            bool Solution_found = false;

            Point[][] solved = new Point[][]
            {
                new Point[]{new Point {X=0,Y=0 },new Point {X=0,Y=1 },new Point {X=0,Y=2 }},
                new Point[]{new Point {X=1,Y=0 },new Point {X=1,Y=1 },new Point {X=1,Y=2 }},
                new Point[]{new Point {X=2,Y=0 },new Point {X=2,Y=1 },new Point {X=2,Y=2 }},
                new Point[]{new Point {X=0,Y=0 },new Point {X=1,Y=0 },new Point {X=2,Y=0 }},
                new Point[]{new Point {X=0,Y=1 },new Point {X=1,Y=1 },new Point {X=2,Y=1 }},
                new Point[]{new Point {X=0,Y=2 },new Point {X=1,Y=2 },new Point {X=2,Y=2 }},
                new Point[]{new Point {X=0,Y=0 },new Point {X=1,Y=1 },new Point {X=2,Y=2 }},
                new Point[]{new Point {X=0,Y=2 },new Point {X=1,Y=1 },new Point {X=2,Y=0 }}
            };

            for (int i = 0; i < board.GetLength(0); i++)
            {
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    if (board[i, j] == 1)
                    {
                        solutionsOnBoardX.Add(new Point(i, j));
                    }
                    if (board[i, j] == 2)
                    {
                        solutionsOnBoardO.Add(new Point(i, j));
                    }
                    if (board[i, j] == 0)
                    {
                        Is_finished = false;
                    }
                }
            }

            if (find_solution(solved, Is_finished, Solution_found, solutionsOnBoardX) == true && find_solution(solved, Is_finished, Solution_found, solutionsOnBoardO) == false && Is_finished == true)
            {
                return 1;
            }
            if (find_solution(solved, Is_finished, Solution_found, solutionsOnBoardX) == true && find_solution(solved, Is_finished, Solution_found, solutionsOnBoardO) == false && Is_finished == false)
            {
                return 1;
            }
            if (find_solution(solved, Is_finished, Solution_found, solutionsOnBoardX) == false && find_solution(solved, Is_finished, Solution_found, solutionsOnBoardO) == true && Is_finished == false)
            {
                return 2;
            }

            if (find_solution(solved, Is_finished, Solution_found, solutionsOnBoardX) == false && find_solution(solved, Is_finished, Solution_found, solutionsOnBoardO) == true && Is_finished == true)
            {
                return 2;
            }

            if (find_solution(solved, Is_finished, Solution_found, solutionsOnBoardX) == false && find_solution(solved, Is_finished, Solution_found, solutionsOnBoardO) == false && Is_finished == true)
            {
                return 0;
            }
            if (find_solution(solved, Is_finished, Solution_found, solutionsOnBoardX) == false && find_solution(solved, Is_finished, Solution_found, solutionsOnBoardO) == false && Is_finished == false)
            {
                return -1;
            }
            else
            {
                return 3;
            }
        }


        static void  Main(string[] args)
        {
            int[,] board = new int[,] {
       
                {2,1,2 },
                {2,1,2 },
                {1,2,1 }
        };
            Console.WriteLine(IsSolved(board));
        }
       
            





        
        public static bool find_solution(Point[][] solved, bool Is_finished, bool Solution_found, List<Point> solutionsOnBoard)
        {
            for (int i = 0; i < solved.Length; i++)
            {
                if (solutionsOnBoard.Count > 3)
                {
                    int correct = 0;
                    for (int j = 0; j < solved[i].Length; j++)
                    {
                        for (int k = 0; k < solutionsOnBoard.Count; k++)
                        { 
                                if (solutionsOnBoard[k] == solved[i][j])
                                {
                                    correct++;
                                } 
                        }
                    }
                   
                    if (correct == 3)
                    {
                        Solution_found = true;
                        return Solution_found;
                    }
                    correct = 0;
                }
                else
                {
                    int corect = 0;
                    for (int k = 0; k < 3; k++)
                    {
                        if (solutionsOnBoard[k] == solved[i][k])
                        {
                            corect++;
                            Solution_found = true;
                            if (corect == 3)
                            {
                             return Solution_found;
                            }
                        }
                        else
                        {
                            corect = 0;
                            Solution_found = false;
                            break;
                        }
                    }

                }

            }
            return Solution_found;
        }
    }
}
